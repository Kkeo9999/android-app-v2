My Money Reset — Android APK project (updated HTML + custom M icon)

ภายใน ZIP นี้
- แอป HTML เวอร์ชันล่าสุด: app/src/main/assets/index.html
- ไอคอน M สีเขียว: app/src/main/res/mipmap-*/ic_launcher.png
- GitHub Actions workflow สำหรับสร้าง APK: .github/workflows/build-apk.yml

สร้าง APK ผ่าน GitHub บนโทรศัพท์ Android
1. แตก ZIP ในแอปจัดการไฟล์บนโทรศัพท์
2. อัปโหลดไฟล์และโฟลเดอร์จากภายใน MyMoneyResetAndroid ไปยัง root ของ repository (อย่าอัปโหลด ZIP อย่างเดียว)
3. ให้โครงสร้างเป็น MyMoneyResetAndroid/app, MyMoneyResetAndroid/build.gradle และ MyMoneyResetAndroid/settings.gradle พร้อม .github/workflows/build-apk.yml ที่ root repository
4. Commit changes ไปยัง branch main หรือ master
5. เปิด Actions แล้วเลือก Build My Money Reset APK
6. รอเครื่องหมายถูกสีเขียว เปิด run นั้น เลื่อนลงหา Artifacts และดาวน์โหลด MyMoneyReset-APK
7. แตก ZIP artifact แล้วแตะไฟล์ .apk เพื่อติดตั้ง

หมายเหตุ
- ZIP นี้เป็นโปรเจกต์สำหรับ build ไม่ใช่ APK ที่คอมไพล์แล้ว
- ถ้ามีไฟล์ .github/workflows/build-apk.yml อยู่แล้ว ให้แก้ไฟล์เดิมแทนการสร้างไฟล์ชื่อซ้ำ
- แอปโหลดไลบรารี/บริการออนไลน์ตามที่ HTML กำหนด และข้อมูล localStorage อาจหายเมื่อล้างข้อมูลหรือถอนการติดตั้ง
- Firebase ต้องมีการตั้งค่าที่ถูกต้องจึงจะซิงค์ได้
